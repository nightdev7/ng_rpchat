ESX = nil

Citizen.CreateThread(function ()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(1)
    end
    while ESX.GetPlayerData() == nil do
        Citizen.Wait(10)
    end
    PlayerData = ESX.GetPlayerData()
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	PlayerData.job = job
end)

RegisterNetEvent('esx_rpchat:sendProximityMessageDo')
AddEventHandler('esx_rpchat:sendProximityMessageDo', function(playerId, title, message, color)
	local source = PlayerId()
    local target = GetPlayerFromServerId(playerId)
    local sourcePed, targetPed = PlayerPedId(), GetPlayerPed(target)
    local sourceCoords, targetCoords = GetEntityCoords(sourcePed), GetEntityCoords(targetPed)
    local distance = GetDistanceBetweenCoords(sourceCoords, targetCoords, true)
    if target == source then
        TriggerEvent('chat:addMessage', {args = {title, message}, color = color})
    elseif distance < 20 and distance ~= 0 and distance > 0.1 then
        TriggerEvent('chat:addMessage', {args = {title, message}, color = color})
    end
end)

RegisterNetEvent('esx_rpchat:sendProximityMessageME')
AddEventHandler('esx_rpchat:sendProximityMessageME', function(playerId, title, message, color)
	local source = PlayerId()
    local target = GetPlayerFromServerId(playerId)
    local sourcePed, targetPed = PlayerPedId(), GetPlayerPed(target)
    local sourceCoords, targetCoords = GetEntityCoords(sourcePed), GetEntityCoords(targetPed)
    local distance = GetDistanceBetweenCoords(sourceCoords, targetCoords, true)
    if target == source then
        TriggerEvent('chat:addMessage', {args = {title, message}, color = color})
    elseif distance < 20 and distance ~= 0 and distance > 0.1 then
        TriggerEvent('chat:addMessage', {args = {title, message}, color = color})
    end
end)

RegisterNetEvent('esx_rpchat:sendProximityMessageOOC')
AddEventHandler('esx_rpchat:sendProximityMessageOOC',function(playerId, title, message, color)
	local source = PlayerId()
    local target = GetPlayerFromServerId(playerId)
    local sourcePed, targetPed = PlayerPedId(), GetPlayerPed(target)
    local sourceCoords, targetCoords = GetEntityCoords(sourcePed), GetEntityCoords(targetPed)
    local distance = GetDistanceBetweenCoords(sourceCoords, targetCoords, true)
    if target == source then
        TriggerEvent('chat:addMessage', {args = {title, message}, color = color})
    elseif distance < 20 and distance ~= 0 and distance > 0.1 then
        TriggerEvent('chat:addMessage', {args = {title, message}, color = color})
    end
end)


RegisterNetEvent('sendProximityMessageTeam')
AddEventHandler('sendProximityMessageTeam', function(id, name, message, xPlayer)
 
    local myId = PlayerId()
    local pid = GetPlayerFromServerId(id)

    if PlayerData.job ~= nil then


        if PlayerData.job.name == 'police' then

            if pid == myId then
                TriggerEvent('chatMessage', "", {255, 0, 0}, "^4[^*^0".. PlayerData.job.label .."^4] ^r^4 " .. name .."  "..": ^0" .. message)
            elseif PlayerData.job.name == xPlayer.job.name then
                TriggerEvent('chatMessage', "", {255, 0, 0}, "^4[^*^0".. xPlayer.job.label .."^4] ^r^4 " .. name .."  "..": ^0" .. message)
            end
        
        elseif PlayerData.job.name == 'ambulance' then

            if pid == myId then
                TriggerEvent('chatMessage', "", {255, 0, 0}, "^8[^*^0".. PlayerData.job.label .."^8] ^r^8 " .. name .." :^0 " .. message)
            elseif PlayerData.job.name == xPlayer.job.name then
                TriggerEvent('chatMessage', "", {255, 0, 0}, "^8[^*^0".. xPlayer.job.label .."^8] ^r^8 " .. name .." :^0 " .. message)
            end

        elseif PlayerData.job.name == 'taxi' then

            if pid == myId then
                TriggerEvent('chatMessage', "", {255, 0, 0}, "^3[^*^0".. PlayerData.job.label .."^3] ^r^3" .. name .." :^0 " .. message)
            elseif PlayerData.job.name == xPlayer.job.name then
                TriggerEvent('chatMessage', "", {255, 0, 0}, "^3[^*^0".. xPlayer.job.label .."^3] ^r^3" .. name .." :^0 " ..message)
            end

        end
	  
    end

end)