ESX = nil
intest = false

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

AddEventHandler('chatMessage', function(playerId, playerName, message)
	if string.sub(message, 1, string.len('/')) ~= '/' then
		CancelEvent()
		TriggerClientEvent('esx_rpchat:sendProximityMessage', -1, playerId, "[OOC] "..playerName, message, {128, 128, 128})		
	end
end)

getIdentity = function(source)
  local xPlayer = ESX.GetPlayerFromId(source)
  local identifier = xPlayer.identifier
  local result = MySQL.Sync.fetchAll("SELECT * FROM users WHERE identifier = @identifier", {['@identifier'] = identifier})
  if result[1] ~= nil then
	local identity = result[1]
	return identity
  else
	return nil
  end
end

function getPlayerName(source,cb)
	local xPlayer = ESX.GetPlayerFromId(source)
	MySQL.Async.fetchAll("SELECT firstname,lastname FROM users WHERE identifier = @identifier", {['@identifier'] = xPlayer.identifier},
		function(result)
			cb(result[1])
		end
	)
end

RegisterCommand('msg', function(source, args, user)
	if GetPlayerName(tonumber(args[1])) then
		local player = tonumber(args[1])
		table.remove(args, 1)
		TriggerClientEvent('chat:addMessage', player, {args = {"^1MSG de "..GetPlayerName(source).. "[" .. source .. "]: ^7" ..table.concat(args, " ")}, color = {255, 153, 0}})
		TriggerClientEvent('chat:addMessage', source, {args = {"^1MSG enviado a "..GetPlayerName(player).. "[" .. player .. "]: ^7" ..table.concat(args, " ")}, color = {255, 153, 0}})

	else
		TriggerClientEvent('chatMessage', source, "SYSTEM", {255, 0, 0}, "ID de jugador incorrecta!")
	end
end)

RegisterCommand('ayuda', function(source, args, rawCommand)
	if source == 0 then
		print('esx_rpchat: you can\'t use this command from rcon!')
		return
	end
	args = table.concat(args, ' ')
	local name = getPlayerName(source)
  	TriggerClientEvent('chat:addMessage', -1, { args = { _U('ayuda_prefix',source), args }, color = { 245,208,051 } })
end, false)

RegisterCommand('pid', function(source, args, rawCommand)
	if source == 0 then
		print('esx_rpchat: you can\'t use this command from rcon!')
		return
	end
	args = table.concat(args, ' ')
	local name = getPlayerName(source)
  	TriggerClientEvent('chat:addMessage', -1, { args = { _U('pid_prefix',source), args }, color = { 0,255,236 } })
end, false)

RegisterCommand('polidispo', function(source, args, rawCommand)
	if source == 0 then
		print('esx_rpchat: you can\'t use this command from rcon!')
		return
	end
	args = table.concat(args, ' ')
	local name = getPlayerName(source)
  	TriggerClientEvent('chat:addMessage', -1, { args = { _U('pdispo_prefix',source), args }, color = { 252,86,86 } })
end, false)

RegisterCommand('ooc', function(source, args, rawCommand)
	if source == 0 then
		print('esx_rpchat: you can\'t use this command from rcon!')
		return
	end
	args = table.concat(args, ' ')
	local name = GetPlayerName(source)
	local id = source
	if Config.EnableESXIdentity then name = GetCharacterName(source) end
	TriggerClientEvent('esx_rpchat:sendProximityMessageOOC', -1, source, _U('ooc_prefix',source),args, { 128, 128, 128 })
end, false)



RegisterCommand('me', function(source, args, rawCommand)
    if source == 0 then cprint('esx_rpchat: you can\'t use this command from rcon!') return end
    args = table.concat(args, ' ')
    local xPlayer = ESX.GetPlayerFromId(source)
    local name = xPlayer.getName()
    TriggerClientEvent('esx_rpchat:sendProximityMessageME',  -1, source,  '['..source..'] Me', args, { 12, 12, 12 })
end, false, {help = '/me', arguments = {name = 'msg', help = 'Pon un mensaje', type = 'player'}})



RegisterCommand('do', function(source, args, rawCommand)
	if source == 0 then
		print('esx_rpchat: you can\'t use this command from rcon!')
		return
	end
	args = table.concat(args, ' ')
	local id = source
	local name = GetPlayerName(source)
	TriggerClientEvent('esx_rpchat:sendProximityMessageDo', -1, source, _U('do_prefix',id,name), args, { 161, 2, 164 })
end, false)

RegisterCommand('lsfd', function(source, args, rawCommand)
	if source == 0 then
		print('esx_rpchat: you can\'t use this command from rcon!')
		return
	end
	local target = ESX.GetPlayerFromId(source)

	if target.job ~= nil and target.job.name == "ambulance" then
		args = table.concat(args, ' ')
		local name = GetPlayerName(source)
		if Config.EnableESXIdentity then name = GetCharacterName(source) end

		TriggerClientEvent('chat:addMessage', -1, {
      template = '<div class="message-box blue" style:"margin-right:3px;"><i class="fas fa-hospital" style = "margin-right:3px; color:rgb(255, 51, 51);"></i> {0} {1}</div>',
      args = { 'Lsfd : ',args }, color = { 255, 51, 51 } })
	end
end, false)

RegisterCommand('lspd', function(source, args, rawCommand)
	if source == 0 then
		print('esx_rpchat: you can\'t use this command from rcon!')
		return
	end
	local target = ESX.GetPlayerFromId(source)

	if target.job ~= nil and target.job.name == "police" or intest then
		args = table.concat(args, ' ')
		local name = GetPlayerName(source)
		if Config.EnableESXIdentity then name = GetCharacterName(source) end

		TriggerClientEvent('chat:addMessage', -1, {
      args = { _U('pol_prefix'), args }, color = { 94, 161, 224 } })
	end
end, false)

RegisterCommand('yellow', function(source, args, rawCommand)
	if source == 0 then
		print('esx_rpchat: you can\'t use this command from rcon!')
		return
	end
	local target = ESX.GetPlayerFromId(source)

	if target.job ~= nil and target.job.name == "yellow" or intest then
		args = table.concat(args, ' ')
		local name = GetPlayerName(source)
		if Config.EnableESXIdentity then name = GetCharacterName(source) end

		TriggerClientEvent('chat:addMessage', -1, {
      args = { _U('yellow_prefix'), args }, color = { 245, 241, 115 } })
	end
end, false)

RegisterCommand('disponible5', function(source, args, rawCommand)
	if source == 0 then
		print('esx_rpchat: you can\'t use this command from rcon!')
		return
	end
	local target = ESX.GetPlayerFromId(source)

	if target.job ~= nil and target.job.name == "police" or intest then
		args = table.concat(args, ' ')
		local name = GetPlayerName(source)
		if Config.EnableESXIdentity then name = GetCharacterName(source) end

		TriggerClientEvent('chat:addMessage', -1, {
      args = { _U('disponible5_prefix'), args }, color = { 91, 172, 245 } })
	end
end, false)

RegisterCommand('disponible1', function(source, args, rawCommand)
	if source == 0 then
		print('esx_rpchat: you can\'t use this command from rcon!')
		return
	end
	local target = ESX.GetPlayerFromId(source)

	if target.job ~= nil and target.job.name == "police" or intest then
		args = table.concat(args, ' ')
		local name = GetPlayerName(source)
		if Config.EnableESXIdentity then name = GetCharacterName(source) end

		TriggerClientEvent('chat:addMessage', -1, {
      args = { _U('disponible1_prefix'), args }, color = { 91, 172, 245 } })
	end
end, false)

RegisterCommand('disponible2', function(source, args, rawCommand)
	if source == 0 then
		print('esx_rpchat: you can\'t use this command from rcon!')
		return
	end
	local target = ESX.GetPlayerFromId(source)

	if target.job ~= nil and target.job.name == "police" or intest then
		args = table.concat(args, ' ')
		local name = GetPlayerName(source)
		if Config.EnableESXIdentity then name = GetCharacterName(source) end

		TriggerClientEvent('chat:addMessage', -1, {
      args = { _U('disponible2_prefix'), args }, color = { 91, 172, 245 } })
	end
end, false)

RegisterCommand('disponible3', function(source, args, rawCommand)
	if source == 0 then
		print('esx_rpchat: you can\'t use this command from rcon!')
		return
	end
	local target = ESX.GetPlayerFromId(source)

	if target.job ~= nil and target.job.name == "police" or intest then
		args = table.concat(args, ' ')
		local name = GetPlayerName(source)
		if Config.EnableESXIdentity then name = GetCharacterName(source) end

		TriggerClientEvent('chat:addMessage', -1, {
      args = { _U('disponible3_prefix'), args }, color = { 91, 172, 245 } })
	end
end, false)

RegisterCommand('disponible4', function(source, args, rawCommand)
	if source == 0 then
		print('esx_rpchat: you can\'t use this command from rcon!')
		return
	end
	local target = ESX.GetPlayerFromId(source)

	if target.job ~= nil and target.job.name == "police" or intest then
		args = table.concat(args, ' ')
		local name = GetPlayerName(source)
		if Config.EnableESXIdentity then name = GetCharacterName(source) end

		TriggerClientEvent('chat:addMessage', -1, {
      args = { _U('disponible4_prefix'), args }, color = { 91, 172, 245 } })
	end
end, false)

RegisterCommand('ocupados', function(source, args, rawCommand)
	if source == 0 then
		print('esx_rpchat: you can\'t use this command from rcon!')
		return
	end
	local target = ESX.GetPlayerFromId(source)

	if target.job ~= nil and target.job.name == "police" or intest then
		args = table.concat(args, ' ')
		local name = GetPlayerName(source)
		if Config.EnableESXIdentity then name = GetCharacterName(source) end

		TriggerClientEvent('chat:addMessage', -1, {
      args = { _U('ocupados_prefix'), args }, color = { 91, 172, 245 } })
	end
end, false)

RegisterCommand('tax', function(source, args, rawCommand)
	if source == 0 then
		print('esx_rpchat: you can\'t use this command from rcon!')
		return
	end
	local target = ESX.GetPlayerFromId(source)

	if target.job ~= nil and target.job.name == "taxi" or intest then
		args = table.concat(args, ' ')
		local name = GetPlayerName(source)
		if Config.EnableESXIdentity then name = GetCharacterName(source) end

		TriggerClientEvent('chat:addMessage', -1, {
      args = { _U('taxi_prefix'), args }, color = { 254, 238, 0 } })
	end
end, false)

RegisterCommand('pearls', function(source, args, rawCommand)
	if source == 0 then
		print('esx_rpchat: you can\'t use this command from rcon!')
		return
	end
	local target = ESX.GetPlayerFromId(source)

	if target.job ~= nil and target.job.name == "pearls" or intest then
		args = table.concat(args, ' ')
		local name = GetPlayerName(source)
		if Config.EnableESXIdentity then name = GetCharacterName(source) end

		TriggerClientEvent('chat:addMessage', -1, {
      args = { _U('pearls_prefix'), args }, color = { 226, 247, 253 } })
	end
end, false)

RegisterCommand('bahamas', function(source, args, rawCommand)
	if source == 0 then
		print('esx_rpchat: you can\'t use this command from rcon!')
		return
	end
	local target = ESX.GetPlayerFromId(source)

	if target.job ~= nil and target.job.name == "bahamas" or intest then
		args = table.concat(args, ' ')
		local name = GetPlayerName(source)
		if Config.EnableESXIdentity then name = GetCharacterName(source) end

		TriggerClientEvent('chat:addMessage', -1, {
      args = { _U('bahamas_prefix'), args }, color = { 29, 0, 75 } })
	end
end, false)

RegisterCommand('unicorn', function(source, args, rawCommand)
	if source == 0 then
		print('esx_rpchat: you can\'t use this command from rcon!')
		return
	end
	local target = ESX.GetPlayerFromId(source)

	if target.job ~= nil and target.job.name == "unicorn" or intest then
		args = table.concat(args, ' ')
		local name = GetPlayerName(source)
		if Config.EnableESXIdentity then name = GetCharacterName(source) end

		TriggerClientEvent('chat:addMessage', -1, {
      args = { _U('unicorn_prefix'), args }, color = { 135, 5, 137 } })
	end
end, false)

RegisterCommand('lscustom', function(source, args, rawCommand)
	if source == 0 then
		print('esx_rpchat: you can\'t use this command from rcon!')
		return
	end
	local target = ESX.GetPlayerFromId(source)

	if target.job ~= nil and target.job.name == "mechanic" or intest then
		args = table.concat(args, ' ')
		local name = GetPlayerName(source)
		if Config.EnableESXIdentity then name = GetCharacterName(source) end

		TriggerClientEvent('chat:addMessage', -1, {
      args = { _U('meca_prefix'), args }, color = { 187, 38, 187 } })
	end
end, false)

local LastPlayer, WantDM, WantSpy = {}, {}, {}
RegisterCommand('msg', function(source, args, user)
    if args[1] then
        if(tonumber(args[1]) and GetPlayerName(tonumber(args[1]))) then
            local xTarget = tonumber(args[1])
            if xTarget == tonumber(source) then
                TriggerClientEvent('chat:addMessage', source, { args = { '^8Privado | ', 'Te has enviado el mensaje a ti mismo'}})
            else
                if WantDM[xTarget] == false or WantDM[source] == false then
                    TriggerClientEvent('chat:addMessage', source, { args = { '^8Privado | ', 'Este jugador ha desabilitado los mensajes privados.'}})
                else
                    local message = args
                    table.remove(message, 1)
                    if(#message == 0) then
                        TriggerClientEvent('chat:addMessage', source, { args = { '^8PM | ', 'Tienes que poner le mensaje'}})
                    else
                        message = table.concat(message, " ")
                        TriggerClientEvent('chat:addMessage', source, {
                        args = { ( '^1' .. GetPlayerName(source) .. '(' .. tonumber(source) .. ')^0 to ^2' .. GetPlayerName(xTarget) .. '(' .. xTarget ..')^0 : ' .. message ) }
                        })
                        TriggerClientEvent('chat:addMessage', xTarget, {
                            args = { ( '^1' .. GetPlayerName(source) .. '(' .. tonumber(source) .. ')^0 to ^2' .. GetPlayerName(xTarget) .. '(' .. xTarget ..')^0 : ' .. message ) }
                        })
                        for a = 0, GetNumPlayerIndices()-1 do
                            local b = tonumber(GetPlayerFromIndex(a))
                            if WantSpy[b] == true then
                                TriggerClientEvent('chat:addMessage', b, {
                                    args = { ( '^1' .. GetPlayerName(source) .. '(' .. tonumber(source) .. ')^0 to ^2' .. GetPlayerName(xTarget) .. '(' .. xTarget ..')^0 : ' .. message ) }
                                })
                            end
                        end
                        LastPlayer[source] = xTarget
                        LastPlayer[xTarget] =  tonumber(source)
                    end
                end
            end
        else
            TriggerClientEvent('chat:addMessage', source, { args = { '^8Privado | ', 'No hay jugadores online con la id ' .. tonumber(args[1])}})
        end
    else
        TriggerClientEvent('chat:addMessage', source, { args = { '^8Privado | ', 'Debes de poner la id'}})
    end
end, false)


RegisterCommand('dados', function(source, args, rawCommand)
	if source == 0 then
		print('esx_rpchat: you can\'t use this command from rcon!')
		return
	end
	local arg = tonumber(args[1]) 
	local name = GetRealPlayerName(source)
	if arg == 1 then
		
		local dice = math.random(1,6)
		args = 'ha tirado un dado, ha sacado un '..dice
		TriggerClientEvent('esx_rpchat:sendProximityMessageME', -1, source, name, args, { 87, 69, 255 })

	elseif arg == 2 then 
		
		local dice1 = math.random(1,6)
		local dice2 = math.random(1,6)
		
			args = "ha tirado 2 dados. Ha sacado un "..dice1.." y un "..dice2

		TriggerClientEvent('esx_rpchat:sendProximityMessageME', -1, source, name, args, { 87, 69, 255 })

	elseif arg == 3 then 

		local dice1 = math.random(1,6)
		local dice2 = math.random(1,6)
		local dice3 = math.random(1,6)		
		args = "ha tirado 3 dados. Ha sacado un "..dice1..", un "..dice2.." y un "..dice3
		TriggerClientEvent('esx_rpchat:sendProximityMessageME', -1, source, name, args, { 87, 69, 255 })
	end
	  
end, false)

function GetRealPlayerName(playerId)
	local xPlayer = ESX.GetPlayerFromId(playerId)

	if xPlayer then
		if Config.EnableESXIdentity then
			if Config.OnlyFirstname then
				return xPlayer.get('firstName')
			else
				return xPlayer.getName()
			end
		else
			return xPlayer.getName()
		end
	else
		return GetPlayerName(playerId)
	end
end