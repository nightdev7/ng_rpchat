Config                      = {}
Config['Locale']            = 'en'  -- Traduccion del script
Config['EnableESXIdentity'] = false -- ¿Quieres activar los nombres IC?
Config['OnlyFirstname']     = false -- ¿Quieres que solo salga el nombre?